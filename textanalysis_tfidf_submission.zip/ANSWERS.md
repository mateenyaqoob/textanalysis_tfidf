# Lab 15: TF-IDF and Automated Text Triage

## Challenge 1: Conversational Filler and Numeric Noise

A word such as "know" can receive a substantial TF-IDF weight when it appears in many documents because TF-IDF depends on both its frequency within a document and its inverse document frequency across the corpus. If a word appears in 25% of documents, its inverse document frequency is lower than that of a rare word, but it is not necessarily zero. As a result, frequent conversational words may still influence clustering.

The refined vectorizer removes specified conversational filler, excludes tokens shorter than three alphabetic characters, and uses `max_df=0.5` to exclude terms appearing in more than half of the documents. The baseline and refined cluster keywords should be compared using the program output. Removing generic words may make technical vocabulary more prominent, but the resulting clusters must be evaluated rather than assumed to improve.

## Challenge 2: Hardware Vocabulary Overlap

The unsupervised clusters can mix `sci.electronics` and `comp.sys.mac.hardware` because both categories may discuss related computer components and hardware problems. Potential shared terms to investigate in the actual posts include "drive," "card," and "monitor"; these should be confirmed against the corpus before being reported as observed findings.

Bigrams can preserve contextual phrases such as "video card" or "Mac OS." This can help distinguish general electronics discussions from Mac-specific hardware discussions because the phrase carries more information than an individual word. However, adding bigrams increases the feature space and does not guarantee better clustering. The crosstab and cluster keywords should be used to assess the result.

## Challenge 3: Rant Length Bias

Bag-of-Words represents a document using raw word counts. Longer posts often contain more occurrences of vocabulary terms and therefore have larger L2 norms. K-Means uses distances to cluster documents, so differences in document length can influence its results.

By default, `TfidfVectorizer` applies L2 normalization to nonzero document vectors. This makes their L2 norms approximately one, reducing the influence of document length and emphasizing relative term importance instead of raw counts. Documents with no features in the fitted vocabulary have zero vectors and are an exception.

The actual norms for the longest and shortest posts are printed by the script and should be used when discussing this dataset.

## Challenge 4: Regulated Compliance Explainability

The `explain_document` function reports the five highest-weighted nonzero TF-IDF features for document index 412, along with their numerical weights. These terms provide a reproducible vocabulary-based explanation of the document's representation and can help an auditor understand the evidence associated with its routing.

TF-IDF is preferable as a transparent baseline when auditability is important because its feature weights and ranking procedure can be directly inspected. Unlike a black-box LLM, it does not require generated explanations to describe its vocabulary-based output. However, TF-IDF alone does not establish clinical meaning, guarantee correct routing, or satisfy every regulatory requirement; human review and additional validation may still be necessary.