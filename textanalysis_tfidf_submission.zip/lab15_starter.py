"""
Unstructured Text Analysis & Automated Triage with TF-IDF
Course: Data Science Tools & Techniques

Instructions:
Complete each TODO section below. You can run this file interactively cell-by-cell
in VS Code / PyCharm / Spyder (using the `# %%` markers) or directly via terminal:
    python lab15_starter.py
"""


# ## Setup & Dataset Loading

# %%
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import nltk

from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.decomposition import TruncatedSVD
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer, WordNetLemmatizer

# Download required NLTK resources quietly
nltk.download("punkt", quiet=True)
nltk.download("punkt_tab", quiet=True)
nltk.download("stopwords", quiet=True)
nltk.download("wordnet", quiet=True)

# Load 4 real-world unstructured user discussion categories
CATEGORIES = [
    "sci.electronics",
    "rec.autos",
    "comp.sys.mac.hardware",
    "sci.med",
]

print("Loading dataset...")
raw_data = fetch_20newsgroups(
    subset="all",
    categories=CATEGORIES,
    remove=("headers", "footers", "quotes"),
)

df = pd.DataFrame(
    {
        "text": raw_data.data,
        "true_label": [raw_data.target_names[i] for i in raw_data.target],
    }
)

# Keep posts with meaningful length (> 50 characters)
df = df[df["text"].str.strip().str.len() > 50].reset_index(drop=True)
print(f"Loaded {len(df)} unstructured user posts.\n")


# %% [markdown]
# ## Step 1: Text Cleaning, Tokenization & Normalization (10 mins)

# %%
sample_post = df["text"].iloc[0][:400]
print("--- Raw Sample Post ---")
print(sample_post)
print("-" * 40)

# TODO 1.1: Tokenize `sample_post` using `word_tokenize`, convert to lowercase,
# and keep only alphabetic tokens (`w.isalpha()`).
#tokens = None  # Replace None with your list comprehension
tokens = [
    w.lower()
    for w in word_tokenize(sample_post)
    if w.isalpha()
]

# TODO 1.2: Remove standard English stopwords using `stopwords.words('english')`.
stop_words = set(stopwords.words("english"))
#filtered_tokens = None  # Replace None
filtered_tokens = [
    w for w in tokens if w not in stop_words
]

# TODO 1.3: Apply PorterStemmer and WordNetLemmatizer (with pos='v') to `filtered_tokens`.
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

#stemmed_tokens = None  # Replace None
stemmed_tokens = [stemmer.stem(w) for w in filtered_tokens]

#lemmatized_tokens = None  # Replace None
lemmatized_tokens = [
    lemmatizer.lemmatize(w, pos="v")
    for w in filtered_tokens
]

if filtered_tokens is not None:
    print("Filtered Tokens:  ", filtered_tokens[:12])
    print("Stemmed Roots:    ", stemmed_tokens[:12])
    print("Lemmatized Words: ", lemmatized_tokens[:12])


# %% [markdown]
# ## Step 2: Bag of Words vs. TF-IDF Feature Extraction (15 mins)

# %%
# TODO 2.1: Initialize CountVectorizer and TfidfVectorizer with:
# stop_words='english', max_features=4000, min_df=5
#bow_vec = None  # Replace None
bow_vec = CountVectorizer(
    stop_words="english",
    max_features=4000,
    min_df=5
)

#tfidf_vec = None  # Replace None
tfidf_vec = TfidfVectorizer(
    stop_words="english",
    max_features=4000,
    min_df=5
)

# TODO 2.2: Fit and transform `df['text']` to create `X_bow` and `X_tfidf`
#X_bow = None  # Replace None
X_bow = bow_vec.fit_transform(df["text"])

#X_tfidf = None  # Replace None
X_tfidf = tfidf_vec.fit_transform(df["text"])

# TODO 2.3: Calculate matrix sparsity (% of zero entries in `X_tfidf`)
if X_tfidf is not None:
    total_elements = X_tfidf.shape[0] * X_tfidf.shape[1]
    sparsity = 100.0 * (1.0 - (X_tfidf.nnz / total_elements))
    print(f"\nTF-IDF Matrix Shape: {X_tfidf.shape} | Sparsity: {sparsity:.2f}%")

    # TODO 2.4: Compute mean score per feature across documents and plot Top 10 TF-IDF words
    tfidf_means = np.asarray(X_tfidf.mean(axis=0)).ravel()
    top_idx = tfidf_means.argsort()[-10:]
    top_words = tfidf_vec.get_feature_names_out()[top_idx]
    top_scores = tfidf_means[top_idx]

    plt.figure(figsize=(8, 4.5))
    plt.barh(top_words, top_scores, color="teal")
    plt.xlabel("Average TF-IDF Weight")
    plt.title("Top 10 Most Influential Words (Baseline TF-IDF)")
    plt.tight_layout()
    plt.savefig("top_features.png", dpi=150)
    plt.show()


# %% [markdown]
# ## Step 3: Automated Topic Discovery & Spatial Mapping (15 mins)

# %%
## if X_tfidf is not None:
    # TODO 3.1: Fit KMeans with `n_clusters=4, random_state=42, n_init=10` on `X_tfidf`
  #  kmeans = None  # Replace None
    # df["cluster"] = kmeans.fit_predict(X_tfidf)

    # TODO 3.2: Print the top 8 defining TF-IDF words per cluster centroid
    # and plot a seaborn heatmap (`cluster_heatmap.png`) of the top 5 words per cluster.

    # TODO 3.3: Project `X_tfidf` to 2 dimensions using `TruncatedSVD(n_components=2, random_state=42)`
    # and save a 2D scatter plot (`spatial_mapping.png`) colored by `df["cluster"]`.
   ## pass

   ##Replacing the step 3 here
   
if X_tfidf is not None:
    # Step 3.1: K-Means clustering
    kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
    df["cluster"] = kmeans.fit_predict(X_tfidf)

    feature_names = tfidf_vec.get_feature_names_out()

    # Step 3.2: Print top 8 words per cluster
    for cluster_id, centroid in enumerate(kmeans.cluster_centers_):
        top_indices = centroid.argsort()[-8:][::-1]
        top_words = feature_names[top_indices]
        print(f"\nCluster {cluster_id} top words: {', '.join(top_words)}")

    # Heatmap: top 5 words for each cluster
    top5_indices = np.argsort(kmeans.cluster_centers_, axis=1)[:, -5:]
    top5_indices = np.flip(top5_indices, axis=1)

    heatmap_data = kmeans.cluster_centers_[
        np.arange(4)[:, None], top5_indices
    ]
    heatmap_words = feature_names[top5_indices]

    plt.figure(figsize=(10, 5))
    sns.heatmap(
        heatmap_data,
        annot=heatmap_words,
        fmt="",
        cmap="YlGnBu",
        xticklabels=False,
        yticklabels=[f"Cluster {i}" for i in range(4)]
    )
    plt.title("Top 5 TF-IDF Words per Cluster")
    plt.tight_layout()
    plt.savefig("cluster_heatmap.png", dpi=150)
    plt.show()

    # Step 3.3: Reduce to two dimensions using TruncatedSVD
    svd = TruncatedSVD(n_components=2, random_state=42)
    X_2d = svd.fit_transform(X_tfidf)

    plt.figure(figsize=(9, 6))
    scatter = plt.scatter(
        X_2d[:, 0],
        X_2d[:, 1],
        c=df["cluster"],
        cmap="viridis",
        s=10,
        alpha=0.65
    )
    plt.xlabel("SVD Component 1")
    plt.ylabel("SVD Component 2")
    plt.title("Document Clusters in 2D TF-IDF Space")
    plt.colorbar(scatter, label="Cluster")
    plt.tight_layout()
    plt.savefig("spatial_mapping.png", dpi=150)
    plt.show()



# %% [markdown]
# ## Step 4: Problem-Solving Diagnostics (20 mins)

# %%
# Challenge 1 (Noise Filtering):
# TODO 4.1: Build a cleaner `TfidfVectorizer` using `token_pattern=r'\b[a-zA-Z]{3,}\b'`,
# `max_df=0.5`, and custom conversational stopwords (e.g., 'know', 'like', 'just', 'think', 'does', 'use', 'thanks').
# Re-fit KMeans and compare cluster keywords!
# Challenge 1: Conversational Filler & Numeric Noise

custom_stopwords = set(stopwords.words("english")) | {
    "know", "like", "just", "think", "does", "use", "thanks"
}

refined_vec = TfidfVectorizer(
    token_pattern=r"\b[a-zA-Z]{3,}\b",
    max_df=0.5,
    max_features=4000,
    min_df=5,
    stop_words=list(custom_stopwords)
)

X_refined = refined_vec.fit_transform(df["text"])

print("\n--- Challenge 1: Baseline vs Refined TF-IDF ---")
print(f"Baseline matrix shape: {X_tfidf.shape}")
print(f"Refined matrix shape:  {X_refined.shape}")

# Fit K-Means on the refined matrix
refined_kmeans = KMeans(
    n_clusters=4,
    random_state=42,
    n_init=10
)
df["refined_cluster"] = refined_kmeans.fit_predict(X_refined)

# Compare the defining words of baseline and refined clusters
baseline_features = tfidf_vec.get_feature_names_out()
refined_features = refined_vec.get_feature_names_out()

for cluster_id in range(4):
    baseline_top = kmeans.cluster_centers_[cluster_id].argsort()[-8:][::-1]
    refined_top = refined_kmeans.cluster_centers_[cluster_id].argsort()[-8:][::-1]

    print(f"\nCluster {cluster_id}")
    print("Baseline:", ", ".join(baseline_features[baseline_top]))
    print("Refined: ", ", ".join(refined_features[refined_top]))

# Challenge 2 (Hardware Overlap Diagnosis):
# TODO 4.2: Run `pd.crosstab(df['true_label'], df['cluster'])` and inspect overlapping categories.
# Challenge 2: Hardware Vocabulary Overlap

print("\n--- Challenge 2: True Categories vs Clusters ---")

cross_tab = pd.crosstab(
    df["true_label"],
    df["cluster"]
)
print(cross_tab)

# Identify which two categories have the greatest overlap
# within any single cluster.
category_names = cross_tab.index.tolist()
best_pair = None
best_overlap = -1
best_cluster = None

for i in range(len(category_names)):
    for j in range(i + 1, len(category_names)):
        for cluster_id in cross_tab.columns:
            overlap = min(
                cross_tab.loc[category_names[i], cluster_id],
                cross_tab.loc[category_names[j], cluster_id]
            )

            if overlap > best_overlap:
                best_overlap = overlap
                best_pair = (category_names[i], category_names[j])
                best_cluster = cluster_id

print(f"\nLargest pairwise overlap in one cluster: {best_pair}")
print(f"Cluster: {best_cluster}")
print(f"Smaller category count in that cluster: {best_overlap}")

# Compare the most characteristic words of the two hardware categories
hardware_categories = [
    "sci.electronics",
    "comp.sys.mac.hardware"
]

for category in hardware_categories:
    category_mask = (df["true_label"] == category).to_numpy()
    category_mean = np.asarray(
        X_tfidf[category_mask].mean(axis=0)
    ).ravel()

    top_indices = category_mean.argsort()[-15:][::-1]
    top_words = baseline_features[top_indices]

    print(f"\nTop words for {category}:")
    print(", ".join(top_words))

# Inspect example posts from the two hardware categories
for category in hardware_categories:
    print(f"\n--- Example posts: {category} ---")
    examples = df.loc[df["true_label"] == category, "text"].head(2)

    for text in examples:
        print(text[:500].replace("\n", " "))
        print("-" * 40)

# Challenge 3 (Rant Length Bias):
# TODO 4.3: Compare L2 vector norms (`np.linalg.norm`) of the longest and shortest posts in `X_bow` vs `X_tfidf`.
# Challenge 3: Rant Length Bias

print("\n--- Challenge 3: Document Length and Vector Norms ---")

# Use character length to identify the longest and shortest posts.
post_lengths = df["text"].str.len()

longest_idx = int(post_lengths.idxmax())
shortest_idx = int(post_lengths.idxmin())

print(
    f"Longest post: index={longest_idx}, "
    f"characters={post_lengths.iloc[longest_idx]}"
)
print(
    f"Shortest post: index={shortest_idx}, "
    f"characters={post_lengths.iloc[shortest_idx]}"
)

# Calculate the L2 norm of a document vector.
# Convert a sparse row to a dense array before using np.linalg.norm.
def document_l2_norm(matrix, doc_idx):
    vector = matrix[doc_idx].toarray().ravel()
    return np.linalg.norm(vector)

for name, matrix in [
    ("Bag of Words", X_bow),
    ("TF-IDF", X_tfidf)
]:
    longest_norm = document_l2_norm(matrix, longest_idx)
    shortest_norm = document_l2_norm(matrix, shortest_idx)

    print(f"\n{name}:")
    print(f"Longest post norm:  {longest_norm:.4f}")
    print(f"Shortest post norm: {shortest_norm:.4f}")

# Challenge 4 (Stakeholder Explainability Audit):
##def explain_document(doc_id, matrix, vectorizer, top_n=5):
# TODO 4.4: Return or print the top_n highest-weighted TF-IDF terms and their exact weights
# for a single document `doc_id` (test with doc_id=412).
#"""
#    pass
def explain_document(doc_id, matrix, vectorizer, top_n=5):
    """
    Display the highest-weighted nonzero TF-IDF features
    for one document and return them as a DataFrame.
    """
    if doc_id < 0 or doc_id >= matrix.shape[0]:
        raise IndexError(
            f"Document index {doc_id} is outside the valid range "
            f"0 to {matrix.shape[0] - 1}."
        )

    # Extract this document's sparse feature vector
    row = matrix[doc_id]
    feature_indices = row.indices
    feature_weights = row.data

    if len(feature_weights) == 0:
        print(f"Document {doc_id} has no nonzero TF-IDF features.")
        return pd.DataFrame(columns=["term", "tfidf_weight"])

    # Rank nonzero features by descending weight
    ranked_positions = np.argsort(feature_weights)[::-1][:top_n]

    feature_names = vectorizer.get_feature_names_out()

    results = pd.DataFrame({
        "term": feature_names[feature_indices[ranked_positions]],
        "tfidf_weight": feature_weights[ranked_positions]
    })

    print(f"\n--- Explainability Report: Document {doc_id} ---")
    print(results.to_string(index=False, float_format=lambda x: f"{x:.6f}"))

    return results

# Explainingv document 412 using the baseline TF-IDF model
explanation = explain_document(
    doc_id=412,
    matrix=X_tfidf,
    vectorizer=tfidf_vec,
    top_n=5
)