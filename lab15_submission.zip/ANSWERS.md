
# Lab 15: TF-IDF and K-Means Clustering

## Challenge 1: Conversational Filler and Numeric Noise

Common words such as "know" and "like" may not be removed by default stopwords. We can remove these words by adding them to a custom stopword list. The max_df parameter removes words that appear in too many documents. The token pattern removes words containing fewer than three letters.

## Challenge 2: Hardware Vocabulary Overlap

Electronics and Mac hardware documents may share words such as "computer", "card", and "drive". These shared words can cause documents from different categories to appear in the same cluster. Bigrams, such as "video card" and "hard drive", can help identify more meaningful phrases.

## Challenge 3: Rant Length Bias

Bag of Words uses raw word counts, so longer documents often have larger vector norms. TF-IDF with L2 normalization usually gives each nonzero document vector a norm close to 1. This reduces the effect of document length when K-Means calculates distances.

## Challenge 4: Explainability

TF-IDF assigns weights to words, allowing us to identify important terms in a document. We can display the top five words and their weights to help explain the document's representation. However, these words alone do not provide a complete explanation of the document's meaning.
