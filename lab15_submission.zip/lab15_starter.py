
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import nltk

from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.decomposition import TruncatedSVD
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer, WordNetLemmatizer

# Download required NLTK resources
nltk.download("punkt", quiet=True)
nltk.download("punkt_tab", quiet=True)
nltk.download("stopwords", quiet=True)
nltk.download("wordnet", quiet=True)

# ---------------------------------
# DATASET LOADING
# ---------------------------------

CATEGORIES = [
    "sci.electronics",
    "rec.autos",
    "comp.sys.mac.hardware",
    "sci.med",
]

print("Loading dataset...")

raw_data = fetch_20newsgroups(
    subset="all",
    categories=CATEGORIES,
    remove=("headers", "footers", "quotes"),
)

df = pd.DataFrame({
    "text": raw_data.data,
    "true_label": [
        raw_data.target_names[i] for i in raw_data.target
    ]
})

df = df[
    df["text"].str.strip().str.len() > 50
].reset_index(drop=True)

print("Total documents:", len(df))
print(df.head())


# ---------------------------------
# STEP 1: TOKENIZATION AND CLEANING
# ---------------------------------

sample_post = df["text"].iloc[0][:400]

print("\nRAW POST:")
print(sample_post)

tokens = [
    w.lower()
    for w in word_tokenize(sample_post)
    if w.isalpha()
]

stop_words = set(stopwords.words("english"))

filtered_tokens = [
    w for w in tokens if w not in stop_words
]

stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

stemmed_tokens = [
    stemmer.stem(w) for w in filtered_tokens
]

lemmatized_tokens = [
    lemmatizer.lemmatize(w, pos="v")
    for w in filtered_tokens
]

print("\nFiltered tokens:", filtered_tokens[:12])
print("Stemmed words:", stemmed_tokens[:12])
print("Lemmatized words:", lemmatized_tokens[:12])


# ---------------------------------
# STEP 2: BAG OF WORDS AND TF-IDF
# ---------------------------------

bow_vec = CountVectorizer(
    stop_words="english",
    max_features=4000,
    min_df=5
)

tfidf_vec = TfidfVectorizer(
    stop_words="english",
    max_features=4000,
    min_df=5
)

X_bow = bow_vec.fit_transform(df["text"])
X_tfidf = tfidf_vec.fit_transform(df["text"])

total_elements = X_tfidf.shape[0] * X_tfidf.shape[1]

sparsity = 100.0 * (
    1.0 - X_tfidf.nnz / total_elements
)

print("\nBoW shape:", X_bow.shape)
print("TF-IDF shape:", X_tfidf.shape)
print(f"TF-IDF sparsity: {sparsity:.2f}%")

# Plot top 10 average TF-IDF features
tfidf_means = np.asarray(
    X_tfidf.mean(axis=0)
).ravel()

top_idx = tfidf_means.argsort()[-10:]

top_words = tfidf_vec.get_feature_names_out()[top_idx]
top_scores = tfidf_means[top_idx]

plt.figure(figsize=(8, 5))
plt.barh(top_words, top_scores)
plt.xlabel("Average TF-IDF Weight")
plt.title("Top 10 TF-IDF Words")
plt.tight_layout()
plt.savefig("top_features.png", dpi=150)
plt.show()


# ---------------------------------
# STEP 3: K-MEANS CLUSTERING
# ---------------------------------

kmeans = KMeans(
    n_clusters=4,
    random_state=42,
    n_init=10
)

df["cluster"] = kmeans.fit_predict(X_tfidf)

feature_names = tfidf_vec.get_feature_names_out()

print("\nTOP WORDS PER CLUSTER")

cluster_top_words = {}

for cluster_no, center in enumerate(kmeans.cluster_centers_):
    top_ids = center.argsort()[-8:][::-1]
    words = feature_names[top_ids]

    cluster_top_words[cluster_no] = list(words)

    print(f"Cluster {cluster_no}:", ", ".join(words))


# Heatmap of top 5 words per cluster
heatmap_words = sorted(set(
    word
    for words in cluster_top_words.values()
    for word in words[:5]
))

word_to_index = {
    word: i for i, word in enumerate(feature_names)
}

heatmap_data = []

for cluster_no in range(4):
    row = [
        kmeans.cluster_centers_[cluster_no][word_to_index[word]]
        for word in heatmap_words
    ]
    heatmap_data.append(row)

plt.figure(figsize=(12, 5))

sns.heatmap(
    np.array(heatmap_data),
    xticklabels=heatmap_words,
    yticklabels=[f"Cluster {i}" for i in range(4)],
    cmap="viridis"
)

plt.title("Cluster-by-Word Importance")
plt.xticks(rotation=60, ha="right")
plt.tight_layout()
plt.savefig("cluster_heatmap.png", dpi=150)
plt.show()


# Reduce dimensions to 2D using SVD
svd = TruncatedSVD(
    n_components=2,
    random_state=42
)

X_2d = svd.fit_transform(X_tfidf)

plt.figure(figsize=(8, 6))

plt.scatter(
    X_2d[:, 0],
    X_2d[:, 1],
    c=df["cluster"],
    cmap="viridis",
    s=10
)

plt.xlabel("SVD Component 1")
plt.ylabel("SVD Component 2")
plt.title("2D Document Clusters")

plt.tight_layout()
plt.savefig("spatial_mapping.png", dpi=150)
plt.show()


# ---------------------------------
# CHALLENGE 1: CLEANER TF-IDF
# ---------------------------------

custom_stopwords = list(
    set(stop_words).union({
        "know", "like", "just", "think",
        "does", "use", "thanks"
    })
)

clean_tfidf_vec = TfidfVectorizer(
    stop_words=custom_stopwords,
    token_pattern=r"\b[a-zA-Z]{3,}\b",
    max_df=0.5,
    max_features=4000,
    min_df=5
)

X_tfidf_clean = clean_tfidf_vec.fit_transform(df["text"])

clean_kmeans = KMeans(
    n_clusters=4,
    random_state=42,
    n_init=10
)

df["clean_cluster"] = clean_kmeans.fit_predict(
    X_tfidf_clean
)

clean_features = clean_tfidf_vec.get_feature_names_out()

print("\nCLEANER TF-IDF TOP WORDS")

for cluster_no, center in enumerate(
    clean_kmeans.cluster_centers_
):
    top_ids = center.argsort()[-8:][::-1]
    words = clean_features[top_ids]

    print(f"Cluster {cluster_no}:", ", ".join(words))


# ---------------------------------
# CHALLENGE 2: CLUSTER COMPARISON
# ---------------------------------

print("\nTRUE LABEL vs CLUSTER")

print(pd.crosstab(
    df["true_label"],
    df["cluster"]
))

print("\nInspect these counts to see which categories overlap.")
print("Clusters are unsupervised, so their numbers do not")
print("automatically correspond to the true category names.")


# Bigram TF-IDF
bigram_vec = TfidfVectorizer(
    stop_words="english",
    ngram_range=(1, 2),
    max_features=4000,
    min_df=5
)

X_bigram = bigram_vec.fit_transform(df["text"])

bigram_kmeans = KMeans(
    n_clusters=4,
    random_state=42,
    n_init=10
)

bigram_clusters = bigram_kmeans.fit_predict(X_bigram)

bigram_features = bigram_vec.get_feature_names_out()

print("\nBIGRAM CLUSTER TOP WORDS")

for cluster_no, center in enumerate(
    bigram_kmeans.cluster_centers_
):
    top_ids = center.argsort()[-8:][::-1]
    print(
        f"Cluster {cluster_no}:",
        ", ".join(bigram_features[top_ids])
    )


# ---------------------------------
# CHALLENGE 3: DOCUMENT LENGTH BIAS
# ---------------------------------

df["text_length"] = df["text"].str.len()

longest_index = df["text_length"].idxmax()
shortest_index = df["text_length"].idxmin()

print("\nLONGEST DOCUMENT INDEX:", longest_index)
print("SHORTEST DOCUMENT INDEX:", shortest_index)

print(
    "Longest document BoW norm:",
    np.linalg.norm(X_bow[longest_index].toarray())
)

print(
    "Shortest document BoW norm:",
    np.linalg.norm(X_bow[shortest_index].toarray())
)

print(
    "Longest document TF-IDF norm:",
    np.linalg.norm(X_tfidf[longest_index].toarray())
)

print(
    "Shortest document TF-IDF norm:",
    np.linalg.norm(X_tfidf[shortest_index].toarray())
)


# ---------------------------------
# CHALLENGE 4: EXPLAIN A DOCUMENT
# ---------------------------------

def explain_document(doc_id, matrix, vectorizer, top_n=5):
    """
    Return a list of (term, weight) tuples for a document row.
    doc_id is a zero-based row position.
    """

    if doc_id < 0 or doc_id >= matrix.shape[0]:
        raise IndexError("Document index is out of range.")

    row = matrix[doc_id]

    if hasattr(row, "toarray"):
        row = row.toarray().ravel()
    else:
        row = np.asarray(row).ravel()

    feature_names = vectorizer.get_feature_names_out()
    nonzero_ids = np.flatnonzero(row)

    top_ids = sorted(
        nonzero_ids,
        key=lambda i: row[i],
        reverse=True
    )[:top_n]

    result = [
        (feature_names[i], float(row[i]))
        for i in top_ids
    ]

    print(f"\nExplanation for document row {doc_id}:")

    for term, weight in result:
        print(f"{term}: {weight:.4f}")

    return result


print("\nDOCUMENT 412 EXPLANATION")

if len(df) > 412:
    explain_document(412, X_tfidf, tfidf_vec, top_n=5)
else:
    print("The dataset does not contain row 412.")

print("\nAll tasks completed.")
print("Generated files:")
print("top_features.png")
print("cluster_heatmap.png")
print("spatial_mapping.png")
