"""
Unstructured Text Analysis & Automated Triage with TF-IDF
Course: Data Science Tools & Techniques

Instructions:
Complete each TODO section below. You can run this file interactively cell-by-cell
in VS Code / PyCharm / Spyder (using the `# %%` markers) or directly via terminal:
    python lab15_starter.py
"""


# ## Setup & Dataset Loading

# %%
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import nltk

from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.decomposition import TruncatedSVD
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer, WordNetLemmatizer

# Download required NLTK resources quietly
nltk.download("punkt", quiet=True)
nltk.download("punkt_tab", quiet=True)
nltk.download("stopwords", quiet=True)
nltk.download("wordnet", quiet=True)

# Load 4 real-world unstructured user discussion categories
CATEGORIES = [
    "sci.electronics",
    "rec.autos",
    "comp.sys.mac.hardware",
    "sci.med",
]

print("Loading dataset...")
raw_data = fetch_20newsgroups(
    subset="all",
    categories=CATEGORIES,
    remove=("headers", "footers", "quotes"),
)

df = pd.DataFrame(
    {
        "text": raw_data.data,
        "true_label": [raw_data.target_names[i] for i in raw_data.target],
    }
)

# Keep posts with meaningful length (> 50 characters)
df = df[df["text"].str.strip().str.len() > 50].reset_index(drop=True)
print(f"Loaded {len(df)} unstructured user posts.\n")


# %% [markdown]
# ## Step 1: Text Cleaning, Tokenization & Normalization (10 mins)

# %%
sample_post = df["text"].iloc[0][:400]
print("--- Raw Sample Post ---")
print(sample_post)
print("-" * 40)

# TODO 1.1: Tokenize `sample_post` using `word_tokenize`, convert to lowercase,
# and keep only alphabetic tokens (`w.isalpha()`).
tokens = [word.lower() for word in word_tokenize(sample_post) if word.isalpha()]

# TODO 1.2: Remove standard English stopwords using `stopwords.words('english')`.
stop_words = set(stopwords.words("english"))
filtered_tokens = [word for word in tokens if word not in stop_words]

# TODO 1.3: Apply PorterStemmer and WordNetLemmatizer (with pos='v') to `filtered_tokens`.
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

stemmed_tokens = [stemmer.stem(word) for word in filtered_tokens]
lemmatized_tokens = [lemmatizer.lemmatize(word, pos='v') for word in filtered_tokens]

if filtered_tokens is not None:
    print("Filtered Tokens:  ", filtered_tokens[:12])
    print("Stemmed Roots:    ", stemmed_tokens[:12])
    print("Lemmatized Words: ", lemmatized_tokens[:12])


# %% [markdown]
# ## Step 2: Bag of Words vs. TF-IDF Feature Extraction (15 mins)

# %%
# TODO 2.1: Initialize CountVectorizer and TfidfVectorizer with:
# stop_words='english', max_features=4000, min_df=5
bow_vec = CountVectorizer(stop_words='english', max_features=4000, min_df=5)
tfidf_vec = TfidfVectorizer(stop_words='english', max_features=4000, min_df=5)

# TODO 2.2: Fit and transform `df['text']` to create `X_bow` and `X_tfidf`
X_bow = bow_vec.fit_transform(df['text'])
X_tfidf = tfidf_vec.fit_transform(df['text'])

# TODO 2.3: Calculate matrix sparsity (% of zero entries in `X_tfidf`)
if X_tfidf is not None:
    total_elements = X_tfidf.shape[0] * X_tfidf.shape[1]
    sparsity = 100.0 * (1.0 - (X_tfidf.nnz / total_elements))
    print(f"\nTF-IDF Matrix Shape: {X_tfidf.shape} | Sparsity: {sparsity:.2f}%")

    # TODO 2.4: Compute mean score per feature across documents and plot Top 10 TF-IDF words
    tfidf_means = np.asarray(X_tfidf.mean(axis=0)).ravel()
    top_idx = tfidf_means.argsort()[-10:]
    top_words = tfidf_vec.get_feature_names_out()[top_idx]
    top_scores = tfidf_means[top_idx]

    plt.figure(figsize=(8, 4.5))
    plt.barh(top_words, top_scores, color="teal")
    plt.xlabel("Average TF-IDF Weight")
    plt.title("Top 10 Most Influential Words (Baseline TF-IDF)")
    plt.tight_layout()
    plt.savefig("top_features.png", dpi=150)
    plt.show()


# %% [markdown]
# ## Step 3: Automated Topic Discovery & Spatial Mapping (15 mins)

# %%
if X_tfidf is not None:
    # TODO 3.1: K-Means clustering
    kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
    df["cluster"] = kmeans.fit_predict(X_tfidf)

    # TODO 3.2: Top words per cluster and heatmap
    feature_names = tfidf_vec.get_feature_names_out()
    centroid_scores = kmeans.cluster_centers_
    top_words_per_cluster = {}

    for cluster_id, centroid in enumerate(centroid_scores):
        top_indices = centroid.argsort()[-8:][::-1]
        top_words_per_cluster[cluster_id] = feature_names[top_indices].tolist()
        print(f"Cluster {cluster_id} top words:",
              top_words_per_cluster[cluster_id])

    heatmap_data = []
    heatmap_labels = []

    for cluster_id, centroid in enumerate(centroid_scores):
        top_indices = centroid.argsort()[-5:][::-1]
        heatmap_data.append(centroid[top_indices])
        heatmap_labels.append(
            [feature_names[i] for i in top_indices]
        )

    plt.figure(figsize=(10, 5))
    sns.heatmap(
        np.array(heatmap_data),
        annot=False,
        cmap="YlGnBu",
        yticklabels=[f"Cluster {i}" for i in range(4)],
        xticklabels=False
    )
    plt.title("Top TF-IDF Scores by Cluster")
    plt.tight_layout()
    plt.savefig("cluster_heatmap.png", dpi=150)
    plt.show()

    # TODO 3.3: Two-dimensional spatial mapping
    svd = TruncatedSVD(n_components=2, random_state=42)
    X_2d = svd.fit_transform(X_tfidf)

    plt.figure(figsize=(8, 6))
    plt.scatter(
        X_2d[:, 0], X_2d[:, 1],
        c=df["cluster"], cmap="viridis",
        s=10, alpha=0.6
    )
    plt.title("2D Spatial Mapping of Text Clusters")
    plt.xlabel("Component 1")
    plt.ylabel("Component 2")
    plt.tight_layout()
    plt.savefig("spatial_mapping.png", dpi=150)
    plt.show()


# %% [markdown]
# ## Step 4: Problem-Solving Diagnostics (20 mins)

# %%

# Challenge 1: Noise Filtering
if X_tfidf is not None:
    from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

    custom_stops = set(ENGLISH_STOP_WORDS) | {
        "know", "like", "just", "think",
        "does", "use", "thanks"
    }

    cleaner_tfidf = TfidfVectorizer(
        stop_words=list(custom_stops),
        token_pattern=r"\b[a-zA-Z]{3,}\b",
        max_df=0.5,
        max_features=4000,
        min_df=5
    )

    X_clean = cleaner_tfidf.fit_transform(df["text"])
    clean_kmeans = KMeans(
        n_clusters=4, random_state=42, n_init=10
    )
    df["clean_cluster"] = clean_kmeans.fit_predict(X_clean)

    clean_features = cleaner_tfidf.get_feature_names_out()
    print("\nChallenge 1: Cleaned cluster keywords")

    for i, centroid in enumerate(clean_kmeans.cluster_centers_):
        idx = centroid.argsort()[-8:][::-1]
        print(f"Cluster {i}:", clean_features[idx].tolist())

    # Challenge 2: Compare original labels with clusters
    print("\nChallenge 2: Actual labels vs clusters")
    if "true_label" in df.columns:
        print(pd.crosstab(df["true_label"], df["cluster"]))

    # Challenge 3: Compare BoW and TF-IDF vector norms
    print("\nChallenge 3: Vector norm comparison")
    lengths = df["text"].str.len()
    longest = lengths.idxmax()
    shortest = lengths.idxmin()

    for name, idx in [("Longest", longest), ("Shortest", shortest)]:
        print(f"{name} post, row {idx}, characters={lengths.loc[idx]}")
        print("BoW L2 norm:", np.linalg.norm(X_bow[idx].toarray()))
        print("TF-IDF L2 norm:", np.linalg.norm(X_tfidf[idx].toarray()))

    # Challenge 4: Explain a document using TF-IDF weights
    def explain_document(doc_id, matrix, vectorizer, top_n=5):
        if doc_id < 0 or doc_id >= matrix.shape[0]:
            print("Invalid document row index:", doc_id)
            return

        row = matrix[doc_id].toarray().ravel()
        words = vectorizer.get_feature_names_out()
        indices = row.argsort()[-top_n:][::-1]

        print(f"Document row index: {doc_id}")
        print(f"Top {top_n} TF-IDF terms and exact weights:")

        for j in indices:
            if row[j] > 0:
                print(f"{words[j]}: {row[j]:.6f}")

    explain_document(412, X_tfidf, tfidf_vec, top_n=5)
